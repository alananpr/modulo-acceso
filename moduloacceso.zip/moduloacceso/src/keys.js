module.exports = {
    database: {
        host: 'localhost',
        user: 'root',
        password: '201710167',
        database: 'moduloacceso'
    }
};